//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MYCTPTEST.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MYCTPTEST_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDC_BUTTON1                     1000
#define IDC_BUTTON_ToBank               1000
#define IDC_BUTTON2                     1001
#define IDC_BUTTON3                     1002
#define IDC_BUTTON4                     1003
#define IDC_BUTTON5                     1004
#define IDC_BTN_ToBank2                 1005
#define IDC_LIST2                       1006
#define IDC_BTN_ToBank3                 1006
#define IDC_BTN_FromBank                1006
#define IDC_BUTTON6                     1007
#define IDC_BUTTON7                     1008
#define IDC_LIST1                       1009
#define IDC_BUTTON8                     1010
#define IDC_EDIT1                       1011
#define IDC_BUTTON9                     1012
#define IDC_BUTTON10                    1013
#define IDC_DATETIMEPICKER2             1016
#define IDC_DATETIMEPICKER_ToBank       1016
#define IDC_STATIC_Time                 1017
#define IDC_STATIC_TimeShow             1017
#define IDC_DATETIMEPICKER_ToBank2      1018
#define IDC_DATETIMEPICKER_FromBank     1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
