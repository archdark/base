// MYCTPTESTDlg.h : ͷ�ļ�
//
#include "TraderSpi.h"

#pragma once


// CMYCTPTESTDlg �Ի���
class CMYCTPTESTDlg : public CDialog
{
// ����
public:
	CMYCTPTESTDlg(CWnd* pParent = NULL);// ��׼���캯��
protected:
//	~CMYCTPTESTDlg();
//CTraderSpi * pUserSpi;
// �Ի�������
	enum { IDD = IDD_MYCTPTEST_DIALOG };
CListCtrl	m_ctrlList;
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;
	
	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
public:
	afx_msg void OnBnClickedButton2();
public:
	afx_msg void OnBnClickedButton3();
public:
	afx_msg void OnBnClickedButton4();
public:
	afx_msg void OnBnClickedButton5();
public:
	afx_msg void OnBnClickedButton6();
public:
	afx_msg void OnBnClickedButton7();

public:
	afx_msg void OnBnClickedButton8();
public:
	afx_msg void OnBnClickedButton9();
public:
	static CMYCTPTESTDlg * pthis ;
	static void showtext(CString info);
	static void returnInfo(CTraderSpi *p,int retNO,CString info);
	void tradeinit();
	int tradestatus;

	void showinfo(CString info);
	void ckzjye();
	void ckyhye();
	void actYZQ();
	void actQZY();
	void lvinit();
CTraderSpi * pUserSpi,*pUserSpi1,**pSpi;
int accountCount;
//CTraderSpi * pUserSpi,pUserSpi1;
public:
	afx_msg void OnBnClickedButton10();
	CDateTimeCtrl m_FromBankTime;
	CDateTimeCtrl m_ToBankTime;
	afx_msg void OnDtnDatetimechangeDatetimepickerFrombank(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	CStatic m_TimeShow;
	afx_msg void OnBnClickedButtonTobank();
//	afx_msg void OnBnClickedButtonFrombank();

	CStatic m_TimeShow2;
	afx_msg void OnBnClickedBtnTobank();
	afx_msg void OnBnClickedBtnTobank2();
	afx_msg void OnBnClickedBtnFrombank();
};
