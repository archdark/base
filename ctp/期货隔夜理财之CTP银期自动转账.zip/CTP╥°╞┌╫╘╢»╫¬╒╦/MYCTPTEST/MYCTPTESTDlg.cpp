//// MYCTPTESTDlg.cpp : ʵ���ļ�
//
#include "stdafx.h"
#include "MYCTPTEST.h"
#include "MYCTPTESTDlg.h"
#include <direct.h>
#include <windows.h>

CThostFtdcTraderApi* pUserApi;
CThostFtdcTraderApi* pUserApi1,**pApi;
CACCOUNTINFO * accountinfo;
CCSVOperator CSVOperator;
int callbackfunstatus;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

	// �Ի�������
	enum { IDD = IDD_ABOUTBOX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CMYCTPTESTDlg �Ի���



CMYCTPTESTDlg* CMYCTPTESTDlg::pthis=NULL;
CMYCTPTESTDlg::CMYCTPTESTDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMYCTPTESTDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	pthis = this;
	callbackfunstatus=0;
}

void CMYCTPTESTDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_ctrlList);
	DDX_Control(pDX, IDC_DATETIMEPICKER_FromBank, m_FromBankTime);
	DDX_Control(pDX, IDC_DATETIMEPICKER_ToBank, m_ToBankTime);
	DDX_Control(pDX, IDC_STATIC_Time, m_TimeShow);
//	DDX_Control(pDX, IDC_STATIC_Time2, m_TimeShow2);
}

BEGIN_MESSAGE_MAP(CMYCTPTESTDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, &CMYCTPTESTDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CMYCTPTESTDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &CMYCTPTESTDlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, &CMYCTPTESTDlg::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON5, &CMYCTPTESTDlg::OnBnClickedButton5)
	ON_BN_CLICKED(IDC_BUTTON6, &CMYCTPTESTDlg::OnBnClickedButton6)
	ON_BN_CLICKED(IDC_BUTTON7, &CMYCTPTESTDlg::OnBnClickedButton7)
	ON_BN_CLICKED(IDC_BUTTON8, &CMYCTPTESTDlg::OnBnClickedButton8)
	ON_BN_CLICKED(IDC_BUTTON9, &CMYCTPTESTDlg::OnBnClickedButton9)
	ON_BN_CLICKED(IDC_BUTTON10, &CMYCTPTESTDlg::OnBnClickedButton10)
	ON_NOTIFY(DTN_DATETIMECHANGE, IDC_DATETIMEPICKER_FromBank, &CMYCTPTESTDlg::OnDtnDatetimechangeDatetimepickerFrombank)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_ToBank, &CMYCTPTESTDlg::OnBnClickedButtonTobank)
//	ON_BN_CLICKED(IDC_BUTTON_FromBank, &CMYCTPTESTDlg::OnBnClickedButtonFrombank)
//ON_BN_CLICKED(IDC_BTN_ToBank, &CMYCTPTESTDlg::OnBnClickedBtnTobank)
ON_BN_CLICKED(IDC_BTN_ToBank2, &CMYCTPTESTDlg::OnBnClickedBtnTobank2)
ON_BN_CLICKED(IDC_BTN_FromBank, &CMYCTPTESTDlg::OnBnClickedBtnFrombank)
END_MESSAGE_MAP()


// CMYCTPTESTDlg ��Ϣ��������

BOOL CMYCTPTESTDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ��������...���˵������ӵ�ϵͳ�˵��С�

	// IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	CSVOperator.LoadCSV("config.csv");	    
	accountCount=0;
	std::string* pString = CSVOperator.GetString(1,1);
	while(pString)
	{
		accountCount++;
		pString = CSVOperator.GetString(accountCount+1,1);
	}
	accountCount-=1;
	lvinit();
	tradestatus=0;
	tradeinit();
	CTime Myset_Time(2020,12,12,9,06,00);
	m_FromBankTime.SetTime(&Myset_Time);
	CTime Myset_Time1(2020,12,12,15,16,00);
	m_ToBankTime.SetTime(&Myset_Time1);
	pthis->SetTimer(1,1000,NULL);
	//
	CTime time;
	time=CTime::GetCurrentTime();//�õ���ǰʱ��
	int week=time.GetDayOfWeek();
	CString s=time.Format("%H:%M");//ת��ʱ���ʽ 
	s=time.Format("%H:%M");//ת��ʱ���ʽ
	if(week>1 && week<7 && s>"09:06" && s<"15:16")
		OnBnClickedBtnTobank2();
	else
		OnBnClickedBtnFrombank();


	//
	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void CMYCTPTESTDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CMYCTPTESTDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ��������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù����ʾ��
//
HCURSOR CMYCTPTESTDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CMYCTPTESTDlg::OnBnClickedButton1()
{
	/*CTime Myset_Time(2020,12,12,9,05,00);
	m_FromBankTime.SetTime(&Myset_Time);
	m_ToBankTime.SetTime(&Myset_Time);*/
	pthis->SetTimer(1,1000,NULL);
}

void CMYCTPTESTDlg::OnBnClickedButton2()
{
	ckzjye();
}

void CMYCTPTESTDlg::showtext(CString info)
{
	AfxMessageBox(info);
}


void CMYCTPTESTDlg::showinfo(CString info)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT1);

	CString strText = _T("");
	//strText=
	pEdit->GetWindowText(strText);
	strText=info+ _T("\r\n")+strText;
	pEdit->SetWindowText(strText);
}


void CMYCTPTESTDlg::returnInfo(CTraderSpi *p,int retNO,CString info)
{
	//�ӿڳ�ʼ���ɹ�
	//while(callbackfunstatus==1) Sleep(500);
	callbackfunstatus=1;
	int _float;
	info = _T(":")+info;
	info = p->INVESTOR_ID+info;
	switch(retNO)
	{
	case 1: //�ӿڳ�ʼ���ɹ�
		{
			//pthis->pUserSpi->ReqUserLogin();
			p->ReqUserLogin();
			break;
		}
	case 2://��¼��ȷ�Ͻ���ɹ�
		{
			//���ʽ����
			if(p->actionSign==3||p->actionSign==6)
			{
				if(p->actionSign==3) 
					p->actionSign=0;
				p->ReqQryTradingAccount();
			}
			//���������
			if(p->actionSign==4)
			{
				p->actionSign=0;
				p->ReqQueryBankAccountMoneyByFuture();
			}
			//��ת��
			if(p->actionSign==5)
			{
				p->actionSign=0;
				p->reqFromBankToFutureByFuture();
			}
			break;
		}
	case 301://���ʽ����ɹ�
		_float=p->checkje;		
		if(p->actionSign==3) 
		{
			p->actionSign=0;
			CSVOperator.SetNumber(p->classnum+2,11,_float);
			pthis->lvinit();
		}
		else if(p->actionSign==6) 
			p->reqFromFutureToBankByFuture();
		break;
	case 401://���������ɹ�
		if(p->actionSign==4) 
			p->actionSign=0;
		else if(p->actionSign==5) 
			p->reqFromBankToFutureByFuture();
		_float=p->checkje;
		CSVOperator.SetNumber(p->classnum+2,10,_float);
		pthis->lvinit();
		break;
	case 501://��ת�ڳɹ�
		p->actionSign=0;
		break;
	case 601://��ת���ɹ�		
		p->actionSign=0;
		_float=p->WithdrawQuota;
		if(_float>1000)
		{
			CSVOperator.SetNumber(p->classnum+2,9,_float);
			CSVOperator.SetNumber(p->classnum+2,10,0);
			CSVOperator.SetNumber(p->classnum+2,11,0);
			pthis->lvinit();
			CSVOperator.SaveCSV("config.csv");
		}
		break;
	default:
		break;
	}
	if(retNO>100) 
		pthis->showinfo(info);
	if(retNO<0) 
		pthis->showinfo(info);
	if(p->actionSign==1)
	{
		if(retNO=401)  
		{
			p->actionSign=2;
			p->reqFromFutureToBankByFuture();
		}
		if(retNO<0) p->actionSign=0;
	}
	callbackfunstatus=0;//�ſ�����
}

void CMYCTPTESTDlg::OnBnClickedButton3()
{
	ckyhye();
}

void CMYCTPTESTDlg::OnBnClickedButton4()
{
	actYZQ();
}

void CMYCTPTESTDlg::OnBnClickedButton5()
{
	actQZY();
}

void CMYCTPTESTDlg::OnBnClickedButton6()
{

}

void CMYCTPTESTDlg::OnBnClickedButton7()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_ctrlList.ModifyStyle(LVS_ICON | LVS_SMALLICON | LVS_LIST, LVS_REPORT);

	//���б��ؼ��в�����
	for (int n = 0; n < 4; n++)
	{
		CString strColumnHeading = _T("");
		strColumnHeading.Format(_T("Column %d"), n);
		m_ctrlList.InsertColumn(n, strColumnHeading, LVCFMT_LEFT, 100);
	}

	CString strText = _T("");

	LVITEM lvItem;

	//���б��ؼ��в�����
	for (int m = 0; m < 10; m++)
	{
		strText.Format(_T("Item %d"), m);

		lvItem.mask = LVIF_TEXT;
		lvItem.iItem = m;
		lvItem.iSubItem = 0;
		lvItem.pszText = strText.GetBuffer(strText.GetLength());

		//�����б���
		m_ctrlList.InsertItem(&lvItem);

		strText.ReleaseBuffer();

		for (int n = 1; n < 3; n++)
		{
			strText.Format(_T("SubItem %d %d"), m, n);

			lvItem.mask = LVIF_TEXT;
			lvItem.iItem = m;
			lvItem.iSubItem = n;
			lvItem.pszText = strText.GetBuffer(strText.GetLength());

			m_ctrlList.SetItem(&lvItem);

			//�������б���
			strText.ReleaseBuffer();
		}
	}
}

void CMYCTPTESTDlg::OnBnClickedButton8()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}

void CMYCTPTESTDlg::OnBnClickedButton9()
{
	CSVOperator.SetNumber(2,8,55865);
	//CSVOperator.SaveCSV("config.csv");
	lvinit();
}


void CMYCTPTESTDlg::OnBnClickedButton10()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	ShellExecute(this->m_hWnd,"open","config.csv","","",SW_SHOW );
}

void CMYCTPTESTDlg::ckzjye()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	for(int i=0;i<accountCount;i++)
	{
		if(pSpi[i]->actionSign!=6) pSpi[i]->actionSign=3;
		//		AfxMessageBox(pSpi[i]->INVESTOR_ID);
		if(pSpi[i]->loginstatus==0) 
			pApi[i]->Init();
		else if(pSpi[i]->loginstatus==2)
			pSpi[i]->ReqQryTradingAccount();
		//Sleep(2000);
	}
}

void CMYCTPTESTDlg::ckyhye()
{
	for(int i=0;i<accountCount;i++)
	{
		pSpi[i]->actionSign=4;
		if(pSpi[i]->loginstatus==0) 
			pApi[i]->Init();
		else if(pSpi[i]->loginstatus==2)
			pSpi[i]->ReqQueryBankAccountMoneyByFuture();
	}
}

void CMYCTPTESTDlg::actYZQ()
{
	for(int i=0;i<accountCount;i++)
	{
		pSpi[i]->actionSign=5;
		if(pSpi[i]->loginstatus==0) 
			pApi[i]->Init();
		else if(pSpi[i]->loginstatus==2)
			pSpi[i]->reqFromBankToFutureByFuture();
	}
}

void CMYCTPTESTDlg::actQZY()
{
	for(int i=0;i<accountCount;i++)
	{
		pSpi[i]->actionSign=6;
		if(pSpi[i]->loginstatus==0) 
			pApi[i]->Init();
		else if(pSpi[i]->loginstatus==2)
			pSpi[i]->ReqQryTradingAccount();
	}
}

void CMYCTPTESTDlg::lvinit()
{
	if(tradestatus==1) return;
	tradestatus=1;
	// ɾ��������
	m_ctrlList.DeleteAllItems() ;    
	// ɾ��������
	while( m_ctrlList.DeleteColumn(0) ) ;

	std::string* pString = CSVOperator.GetString(1,1);
	m_ctrlList.ModifyStyle(LVS_ICON | LVS_SMALLICON | LVS_LIST, LVS_REPORT);

	//pString = CSVOperator.GetString(2,4);
	if (pString)
	{
		//���б��ؼ��в�����
		for (int n = 0; n < 3; n++)
		{
			pString = CSVOperator.GetString(1,n+1);
			if(n==2)
				m_ctrlList.InsertColumn(n, pString->c_str(), LVCFMT_LEFT, 100);
			else
				m_ctrlList.InsertColumn(n, pString->c_str(), LVCFMT_LEFT, 80);
		} 
		pString = CSVOperator.GetString(1,9);
		m_ctrlList.InsertColumn(3, pString->c_str(), LVCFMT_LEFT, 100);
		pString = CSVOperator.GetString(1,10);
		m_ctrlList.InsertColumn(4, pString->c_str(), LVCFMT_LEFT, 100);
		pString = CSVOperator.GetString(1,11);
		m_ctrlList.InsertColumn(5, pString->c_str(), LVCFMT_LEFT, 100);
	}
	int i=2;
	LVITEM lvItem;
	CString strText = _T("");
	pString = CSVOperator.GetString(i,1);
	while (pString)
	{
		//���б��ؼ��в�����

		lvItem.mask = LVIF_TEXT;
		lvItem.iItem = i-2;
		lvItem.iSubItem = 0;
		strText=pString->c_str();
		lvItem.pszText = strText.GetBuffer(strText.GetLength());

		//�����б���
		m_ctrlList.InsertItem(&lvItem);

		for (int n = 1; n <3 ; n++)
		{
			pString = CSVOperator.GetString(i,n+1);

			lvItem.mask = LVIF_TEXT;
			lvItem.iItem = i-2;
			lvItem.iSubItem = n;
			strText=pString->c_str();
			lvItem.pszText = strText.GetBuffer(strText.GetLength());
			m_ctrlList.SetItem(&lvItem);

			//�������б���
			//strText.ReleaseBuffer();
		}
		pString = CSVOperator.GetString(i,9);

		lvItem.mask = LVIF_TEXT;
		lvItem.iItem = i-2;
		lvItem.iSubItem = 3;
		strText=pString->c_str();
		lvItem.pszText = strText.GetBuffer(strText.GetLength());
		m_ctrlList.SetItem(&lvItem);
		pString = CSVOperator.GetString(i,10);

		lvItem.mask = LVIF_TEXT;
		lvItem.iItem = i-2;
		lvItem.iSubItem = 4;
		strText=pString->c_str();
		lvItem.pszText = strText.GetBuffer(strText.GetLength());
		m_ctrlList.SetItem(&lvItem);
		pString = CSVOperator.GetString(i,11);

		lvItem.mask = LVIF_TEXT;
		lvItem.iItem = i-2;
		lvItem.iSubItem = 5;
		strText=pString->c_str();
		lvItem.pszText = strText.GetBuffer(strText.GetLength());
		m_ctrlList.SetItem(&lvItem);
		i++;
		pString = CSVOperator.GetString(i,1);
	}
	tradestatus=0;
}


void CMYCTPTESTDlg::tradeinit()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	// ��ʼ��UserApi

	pApi = new CThostFtdcTraderApi*[accountCount];//(CThostFtdcTraderApi**)malloc(sizeof(CThostFtdcTraderApi*)*accountCount);
	pSpi = new CTraderSpi*[accountCount];//(CTraderSpi**)malloc(sizeof(CTraderSpi*)*accountCount);
	TCHAR szFilePath[MAX_PATH + 1]={0};
	GetModuleFileName(NULL, szFilePath, MAX_PATH);
	(_tcsrchr(szFilePath, _T('\\')))[1] = 0; // ɾ���ļ�����ֻ���·���ִ�
	CString str_url = szFilePath;
	//std::string*  pString;// = CSVOperator.GetString(1,1);
	CString cst;
	float crje=0.0f;
	for(int i=0;i<accountCount;i++)
	{
		//str_url+="1\\";
		str_url.Format("%s%d\\",szFilePath,i);
		_mkdir(str_url);
		pApi[i] = CThostFtdcTraderApi::CreateFtdcTraderApi(str_url);			// ����UserApi
		pSpi[i] = new CTraderSpi();
		//----------------------------------
		CSVOperator.GetFloat(i+2,9,crje);
		pSpi[i]->WithdrawQuota=crje;
		strcpy(pSpi[i]->INSTRUMENT_ID,"AG1401");	// ��Լ����
		pSpi[i]->DIRECTION = THOST_FTDC_D_Sell;	// �������� 
		pSpi[i]->LIMIT_PRICE = 2850;				// �۸�
		// ������
		pSpi[i]->iRequestID = 0;
		//pString= CSVOperator.GetString(i+2,7);//->c_str());//+CSVOperator.GetString(i,6)->c_str();
		cst.Format("tcp://%s:41205",CSVOperator.GetString(i+2,7)->c_str());		
		strcpy(pSpi[i]->BankID,CSVOperator.GetString(i+2,8)->c_str());
		strcpy(pSpi[i]->FRONT_ADDR,cst);//"tcp://180.168.212.51:41205");		// ǰ�õ�ַ180.169.116.211 6050
		strcpy(pSpi[i]->BROKER_ID,CSVOperator.GetString(i+2,6)->c_str());			// ���͹�˾����
		strcpy(pSpi[i]->INVESTOR_ID,CSVOperator.GetString(i+2,3)->c_str());		// Ͷ���ߴ���
		strcpy(pSpi[i]->PASSWORD,CSVOperator.GetString(i+2,4)->c_str());			// �û�����
		strcpy(pSpi[i]->zjpwd,CSVOperator.GetString(i+2,5)->c_str());
		pSpi[i]->pUserApi = pApi[i];
		//----------------------------------
		pSpi[i]->SetParam(showtext);
		pSpi[i]->SetParamB(returnInfo);
		pApi[i]->RegisterSpi((CThostFtdcTraderSpi*)pSpi[i]);			// ע���¼���
		pApi[i]->SubscribePublicTopic(THOST_TERT_QUICK);					// ע�ṫ����
		pApi[i]->SubscribePrivateTopic(THOST_TERT_QUICK);					// ע��˽����
		pApi[i]->RegisterFront(pSpi[i]->FRONT_ADDR);							// connect
		pSpi[i]->classnum=i;
	}

}



void CMYCTPTESTDlg::OnDtnDatetimechangeDatetimepickerFrombank(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMDATETIMECHANGE pDTChange = reinterpret_cast<LPNMDATETIMECHANGE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	*pResult = 0;
}


void CMYCTPTESTDlg::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	//pthis->KillTimer(1);
	CDialog::OnTimer(nIDEvent);
	CTime time,timeYZQ,timeQZY;
	CString sTitleF,sTitleT;
	time=CTime::GetCurrentTime();//�õ���ǰʱ��
	CString s=time.Format("%H:%M:%S");//ת��ʱ���ʽ
	// m_TimeShow.SetDlgItemTextA()
	
	GetDlgItem(IDC_STATIC_TimeShow)->SetWindowText(s);

	s=time.Format("%H:%M");//ת��ʱ���ʽ
	//��ת��
	m_FromBankTime.GetTime(timeYZQ);
	CString sFT,sTT;
	sFT=timeYZQ.Format("%H:%M");//ת��ʱ���ʽ
	GetDlgItem(IDC_BTN_FromBank)->GetWindowText(sTitleF);
	
	m_ToBankTime.GetTime(timeQZY);
	sTT=timeQZY.Format("%H:%M");//ת��ʱ���ʽ
	GetDlgItem(IDC_BTN_ToBank2)->GetWindowText(sTitleT);
	int week=time.GetDayOfWeek();
	if(week>1 && week<7 && s==sFT&&sTitleF=="ֹͣ") 
	{		
		showinfo("��ת��");
		OnBnClickedBtnFrombank();
		if(sTitleT=="����") OnBnClickedBtnTobank2();
		actYZQ();
		/*if() 
		{
			GetDlgItem(IDC_BTN_FromBank)->SetWindowText("����");
			m_FromBankTime.EnableWindow(true);
		}*/
	}
	//��ת��
	
	if(week>1 && week<7 &&s==sTT&&sTitleT=="ֹͣ")  
	{	
		showinfo("��ת��");
		OnBnClickedBtnTobank2();
		if(sTitleF=="����") OnBnClickedBtnFrombank();
		actQZY();
		
	}

	//showinfo(ss);
	//s=m_FromBankTime.Value.ToString("yyyy-MM-dd   :   HH:mm:ss");
}


void CMYCTPTESTDlg::OnBnClickedButtonTobank()
{
	CString sTitle;
	GetDlgItem(IDC_BUTTON_ToBank)->GetWindowText(sTitle);
	if(sTitle=="����") 
	{
		GetDlgItem(IDC_BUTTON_ToBank)->SetWindowText("ֹͣ");
	}
	else
		GetDlgItem(IDC_BUTTON_ToBank)->SetWindowText("����");
}

void CMYCTPTESTDlg::OnBnClickedBtnTobank2()
{
			CString sTitle;
	GetDlgItem(IDC_BTN_ToBank2)->GetWindowText(sTitle);
	if(sTitle=="����") 
	{
		GetDlgItem(IDC_BTN_ToBank2)->SetWindowText("ֹͣ");
		m_ToBankTime.EnableWindow(false);
	}
	else
	{
		GetDlgItem(IDC_BTN_ToBank2)->SetWindowText("����");
		m_ToBankTime.EnableWindow(true);
	}
}


void CMYCTPTESTDlg::OnBnClickedBtnFrombank()
{
		CString sTitle;
	GetDlgItem(IDC_BTN_FromBank)->GetWindowText(sTitle);
	if(sTitle=="����") 
	{
		GetDlgItem(IDC_BTN_FromBank)->SetWindowText("ֹͣ");
		m_FromBankTime.EnableWindow(false);
	}
	else
	{
		GetDlgItem(IDC_BTN_FromBank)->SetWindowText("����");
		m_FromBankTime.EnableWindow(true);
	}
}
