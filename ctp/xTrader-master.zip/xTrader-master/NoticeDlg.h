#pragma once

#define IDD_DLG_NOTICE 105
// CNoticeDlg �Ի���

class CNoticeDlg : public CDialog
{
	DECLARE_DYNAMIC(CNoticeDlg)

public:
	CNoticeDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CNoticeDlg();
// �Ի�������
	enum { IDD = IDD_DLG_NOTICE };

	CString m_SzMsg;
	CString m_szTitle;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnOK();
	afx_msg void OnCancel();
};
