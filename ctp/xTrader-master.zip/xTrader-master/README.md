﻿xTrader by t0trader
a win32 MFC/C++ project based on CTP API (Shanghai Futures Information Technology) 基于上期技术综合交易平台的win32 MFC/C++程序。 金融大时代迎面而来，特开放以便于修复各种小bugs，在期货市场共进步。

◆本软件特色:

MFC/C++开发,基于CTP平台接口,可交易国内四大期货交易所品种.
加入股票接口,同样可交易沪深股市.大致特色如下:

1.精简界面,支持银期转账,以及查询结算单.

2.NTP自动15分钟网络校时.

3.行情,交易登陆后可一直保持在线,有重连机制.

4.超出单笔下单限制可自动批量完成.

5.所有列表均可导出为csv文件.

6.慢慢发掘吧,我做了相当多细节优化.

◆意见和建议:

t0trader@qq.com